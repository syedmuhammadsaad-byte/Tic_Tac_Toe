#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <time.h>

// Player structure
struct player {
	char name[20];
	char symbol;
	int score;
} p[2];

// Global Variables
char board[3][3];
const char PLAYER1 = 'X';
const char PLAYER2 = 'O';
char mode;

// Function Prototypes
void resetBoard();
void displayBoard();
int freeSpaces();
void playerMove(int n);
void computerMove();
char checkWinner();
void printWinner(char);
void updateScores(char name[], int score);


int main() {
	char winner = ' ';
	char again = 'Y';

	// Start Game & keep playing as long as user enters 'Y'
	while (again == 'Y') {
		// Reset output screen, winner, board & player scores
		system("cls");
		winner = ' ';
		resetBoard();
		p[0].score = 0;
		p[1].score = 0;

		// Input Game Mode & Proceed Accordingly
		printf("---GAME MODE---\n1. Versus Computer\n2. Multiplayer\nSelect Mode: ");
		scanf(" %c", &mode);
		fflush(stdin);

		// Single player (vs. Computer)
		if (mode == '1')
		{
			// Input player name & set their symbol
			printf("Enter player name: ");
			scanf("%s", p[0].name);
			p[0].symbol = PLAYER1;
			
			// While there is no winner & board has free spaces
			while (winner == ' ' && freeSpaces() != 0) {
				displayBoard();

				// Prompt player1 for their move and update the board (Passing 1 to 'n')
				playerMove(1);	
				winner = checkWinner();
				// If someone won OR Board filled:
				if (winner != ' ' || freeSpaces() == 0)
					break;

				// Simulate computer's move and update the board
				computerMove();
				// Check if there is a winner
				winner = checkWinner();

			}	// End of while (Board completely filled OR someone Won)

		// Multiplayer (vs. Player 2)
		} 
		else if (mode == '2') 
		{
			printf("Enter player1 name: ");
			scanf("%s", p[0].name);
			p[0].symbol = PLAYER1;

			printf("Enter player2 name: ");
			scanf("%s", p[1].name);
			p[1].symbol = PLAYER2;
			
			// While there is no winner & spaces are free
			while (winner == ' ' && freeSpaces() != 0) {
				displayBoard();

				playerMove(1); // Prompt player1 for their move and update the board (Passing 1 to 'n')
				winner = checkWinner();	// Check if there is a winner
				if (winner != ' ' || freeSpaces() == 0)
					break; // If someone won OR Board filled: Break

				displayBoard(); // displaying Board after player1's turn.

				playerMove(2);	// Prompt player2 for their move and update the board (Passing 2 to 'n')
				winner = checkWinner();	// Check if there is a winner
				
			} // End of while (Board completely filled OR someone Won)

		} else {
			printf("Invalid mode! Try again.\n");
			Sleep(500);	// Hold the screen for 100ms before it clears again
			continue;
		}
		// Display final board
		displayBoard();
		// Print the winner according to the symbol returned by checkWinner()
		printWinner(winner);

		printf("\nWould you like to play again? (Y/N): ");
		scanf(" %c", &again);
		again = toupper(again);	// To accept 'y' as 'Y' too
	}
	printf("Thanks for playing!");
	return 0; // Making sure that the program executed correctly
}


/* Reset the board to an empty state, filling all spaces with blank spaces */
void resetBoard() {
	int i, j;
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++)
			board[i][j] = ' ';
	}
}


/* Display the current status of the board */
void displayBoard() {
	system("cls");
	printf(" %c | %c | %c ", board[0][0], board[0][1], board[0][2]);
	printf("\n---|---|---\n");
	printf(" %c | %c | %c ", board[1][0], board[1][1], board[1][2]);
	printf("\n---|---|---\n");
	printf(" %c | %c | %c ", board[2][0], board[2][1], board[2][2]);
	printf("\n");
}


/* Checks and returns no. of free spaces on the board */
int freeSpaces() {
	int i, j, spaces = 9;
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) {
			if (board[i][j] != ' ')
				spaces--;
		}
	}
	return spaces;
}


/* Asks the player to select a valid position, update board according to player's symbol. The parameter n is used to determine which player is making the move */
void playerMove(int n) {
	int x, y;
	printf("%s's turn\n", p[n-1].name);
	printf("Enter row number (1-3): ");
	scanf("%d", &x);
	printf("Enter column number (1-3): ");
	scanf("%d", &y);
	x--, y--;	// To represent as Board Index

	if (x >= 0 && x <= 2 && y >= 0 && y <= 2) {
		if (board[x][y] == ' ') {
			if(n == 1)
				board[x][y] = PLAYER1;
			else
				board[x][y] = PLAYER2;
		} else {
			printf("That space is already occupied!\n");
			playerMove(n);
		}
	} else {
		printf("Invalid coordinates!\n");
		playerMove(n);
	}
}


/* Simulate the computer's move by randomly selecting an empty space on the board and updating it with the computer's symbol */
void computerMove() {
	int x, y;
	printf("Computer's turn\n");
	srand(time(0)); // Seed random number generator (w.r.t current time)

	do {
		x = rand() % 3;
		y = rand() % 3;
	} while (board[x][y] != ' '); // As long as the space isn't empty

	board[x][y] = PLAYER2;
}


/* Check all possible winning combinations on the board and return the symbol of the winning player (if any) */
char checkWinner() {
	int i;
	//check rows
	for(i = 0; i < 3; i++) {
		if(board[i][0] == board[i][1] && board[i][0] == board[i][2])
			return board[i][0];
	}
	//check columns
	for(i = 0; i < 3; i++) {
		if(board[0][i] == board[1][i] && board[0][i] == board[2][i])
			return board[0][i];
	}
	//check diagonals
	if(board[0][0] == board[1][1] && board[0][0] == board[2][2])
		return board[0][0];

	if(board[0][2] == board[1][1] && board[0][2] == board[2][0])
		return board[0][2];

	return ' ';
}


/* Print the name of the winner or a message indicating a tie. The parameter is the symbol of the winning player (' ' means no winner) */
void printWinner(char winner) {
	if (winner == PLAYER1) {
		printf("%s wins!\n", p[0].name);
		updateScores(p[0].name, ++p[0].score);
	}
	else if (winner == PLAYER2) {
		if (mode == '1')
			printf("Computer wins!\n");
		else {
			printf("%s wins!\n", p[1].name);
			updateScores(p[1].name, ++p[1].score);
		}
	}	
	else
		printf("It's a tie!\n");
}


/* Update OR add a new player record (name & score) in a file. 'name' & 'score' are the player name & score to be added passed by printWinner() */
void updateScores(char name[], int score) {
	struct player p;
    int updated = 0;
    
	// Open 'scores.txt' in read mode
    FILE *file = fopen("scores.txt", "r"); // Try to open an existing file
    if (file == NULL) {
    	
    	// Try to create a new file by write mode
    	file = fopen("scores.txt", "w");
    	
    	// If still can't open: Exit with a warning
    	if(file == NULL) {
    		printf("Error opening file!\n");
	        exit(1);
		}
		// Write data & close the file (if file is created just now, only need to add the current record)
    	fprintf(file, "%s %d\n", name, score);
    	fclose(file);
    	return;
    }

    // Create a temporary file & open it in write mode
    FILE *tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        printf("Error creating temporary file!\n");
        fclose(file);
        exit(1);
    }

    // Check if the fscanf() can read the 2 inputs (name & score) successfully from the file
    while (fscanf(file, "%s %d", p.name, &p.score) == 2) {

    	// Check if the player record exists in the file
        if (strcmp(p.name, name) == 0) {
            p.score += score;
            updated = 1;
        }
        // Write the record to the temporary file (weather updated or not)
        fprintf(tempFile, "%s %d\n", p.name, p.score);
    }
    fclose(file);	// Close 'scores.txt' to open it write mode
    if (!updated) {
        // Append the new record to the temporary file
        fprintf(tempFile, "%s %d\n", name, score);
    }
	fclose(tempFile);	// Close 'temp.txt' to open it read mode
	
    // Overwrite the original file with the updated records from the tempFile
    file = fopen("scores.txt", "w");
    tempFile = fopen("temp.txt", "r");
    if (file == NULL || tempFile == NULL) {
        printf("Error opening file(s)!\n");
        fclose(tempFile);
        fclose(file);
        exit(1);
    }
    int c;
    while ((c = fgetc(tempFile)) != EOF) {
        fputc(c, file);
    }
    // Close files & remove delete temporary file
    fclose(file);
    fclose(tempFile);
    remove("temp.txt");
}

